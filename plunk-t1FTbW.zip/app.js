var app = angular.module('plunker', ['ngRoute']);

var baseUrl = 'https://jsonplaceholder.typicode.com/';

app.config(function($routeProvider){
  $routeProvider
  .when('/home',{
    templateUrl:'home.html',
    contrtoller:'homeCtrl'
  })
  .when('/view',{
    templateUrl:'view.html',
    contrtoller:'viewCtrl'
  })
  
  .otherwise({
    redirectTo:'/home'
  })
  
})


app.controller('MainCtrl', function($scope,$http) {
  $scope.name = 'World';
  $scope.indexes;
  $scope.tempArr={};

          $http.get(baseUrl+'users').
            success(function (data, status, headers, config) {
                //alert('Your full name is - ' + data[0].id);
                
                $scope.mydata = data;
                $scope.tempArr = data;
            //alert($scope.mydata[0].address.street);
                
            }).
            error(function (data, status, headers, config) {
                alert("Please check the connection");
            });
            
      
      $scope.deleteData = function(index)
      {
        //$scope.datas = data;
       // alert(index);
        //alert($scope.tempArr[0].id);
          $scope.tempArr.splice(index,1);  
      }
 
 $scope.editData = function(data,index)
 {
   $scope.names= data.name;
   $scope.usrname= data.username;
   $scope.emails= data.email;
   $scope.phones= data.phone;
   $scope.websites= data.website;
   $scope.indexes = index;
  
   //alert($scope.indexes);
   
 }
 
$scope.submitData=function(name,username,email,phone,website)
{
   
   $scope.tempArr[$scope.indexes].name=$scope.changename;
   $scope.tempArr[$scope.indexes].username=username;
   $scope.tempArr[$scope.indexes].email=email;
   $scope.tempArr[$scope.indexes].phone=phone;
   $scope.tempArr[$scope.indexes].website=website;
   
  
}

$scope.addData=function()
{
  $scope.tempArr.push({"id":11,"name":$scope.name,"username":'abanand.92',"email":'abanand.92@gmail.com',
    "phone":9884582244,"website":'',"company":{"name":$scope.companyname}
  });
}


  
})

